﻿using System;
namespace WeekD
{
    using System;

    public class Lab3
    {
        public double account = 45.32;
        public double execution;
        public double absolutevalueIN;


        public Lab3()
        {
            Console.WriteLine("Please enter an value. Negative numbers for withdrawls");

            this.absolutevalueIN = Convert.ToDouble(Console.ReadLine());

            if (this.absolutevalueIN > 0)
            {
                this.account += absolutevalueIN;
                Console.WriteLine("New balance: $" + this.account.ToString());
            }
            else if (this.absolutevalueIN < 0)
            {
                this.execution = this.account + this.absolutevalueIN;
                if (this.execution < 0)
                {
                    Console.WriteLine("\nYou can't take that much out!!");
                }
                else if (this.execution > 0)
                {
                    Console.WriteLine("\nNew balance is: $" + this.execution);
                    Console.WriteLine("\n Here is your $" + Math.Abs(this.absolutevalueIN));
                }
            }
        }

    }
}
