﻿using System;

namespace WeekD
{
    class Program
    {
        static void Main(string[] args)
        {
            Lab3 Lab = new Lab3();

        }
    }
}
