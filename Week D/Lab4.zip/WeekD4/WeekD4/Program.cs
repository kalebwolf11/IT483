﻿using System;

namespace WeekD4
{
    class Program
    {
        static void Main(string[] args)
        {
            Lab4 ave = new Lab4();
        }
    }
}
